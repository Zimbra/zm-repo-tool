echo "abc-sample-ver: 8.7.1+1498186375-1"
