echo "abc-sample-ver: 8.7.2+1498186376-1"
