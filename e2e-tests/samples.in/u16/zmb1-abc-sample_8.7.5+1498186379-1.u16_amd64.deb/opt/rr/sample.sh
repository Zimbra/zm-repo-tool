echo "abc-sample-ver: 8.7.5+1498186379-1"
