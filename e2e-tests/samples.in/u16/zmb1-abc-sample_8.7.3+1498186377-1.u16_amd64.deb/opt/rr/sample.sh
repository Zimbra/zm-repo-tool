echo "abc-sample-ver: 8.7.3+1498186377-1"
