echo "abc-sample-ver: 8.7.0+1498186374-1"
