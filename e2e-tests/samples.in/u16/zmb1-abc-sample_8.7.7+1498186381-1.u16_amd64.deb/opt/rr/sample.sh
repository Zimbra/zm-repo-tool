echo "abc-sample-ver: 8.7.7+1498186381-1"
