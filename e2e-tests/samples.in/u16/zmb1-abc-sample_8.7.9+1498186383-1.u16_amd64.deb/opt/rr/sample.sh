echo "abc-sample-ver: 8.7.9+1498186383-1"
