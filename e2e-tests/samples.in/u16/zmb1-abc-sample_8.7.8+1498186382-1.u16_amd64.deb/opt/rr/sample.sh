echo "abc-sample-ver: 8.7.8+1498186382-1"
