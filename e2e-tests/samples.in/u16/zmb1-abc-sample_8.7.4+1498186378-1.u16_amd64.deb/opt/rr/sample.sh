echo "abc-sample-ver: 8.7.4+1498186378-1"
