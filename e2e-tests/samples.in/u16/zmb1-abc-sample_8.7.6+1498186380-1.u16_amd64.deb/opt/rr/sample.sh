echo "abc-sample-ver: 8.7.6+1498186380-1"
